var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/artworks/[id]/image/route.js")
R.c("server/chunks/[root-of-the-server]__20nns49._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_artworks_[id]_image_route_actions_05go0gd.js")
R.m(75069)
module.exports=R.m(75069).exports
