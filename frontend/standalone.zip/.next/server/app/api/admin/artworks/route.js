var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/artworks/route.js")
R.c("server/chunks/[root-of-the-server]__1scmg6u._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_artworks_route_actions_0aqq2bc.js")
R.m(40913)
module.exports=R.m(40913).exports
