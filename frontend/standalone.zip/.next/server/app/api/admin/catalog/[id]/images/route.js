var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/catalog/[id]/images/route.js")
R.c("server/chunks/[root-of-the-server]__0b9frp9._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_catalog_[id]_images_route_actions_1bumu5x.js")
R.m(82030)
module.exports=R.m(82030).exports
