var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/catalog/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1txx1nc._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_catalog_[id]_route_actions_1vhtuvy.js")
R.m(75018)
module.exports=R.m(75018).exports
