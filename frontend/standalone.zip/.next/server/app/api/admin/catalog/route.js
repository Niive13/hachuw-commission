var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/catalog/route.js")
R.c("server/chunks/[root-of-the-server]__0h5vsq7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_catalog_route_actions_0wonb3b.js")
R.m(98681)
module.exports=R.m(98681).exports
