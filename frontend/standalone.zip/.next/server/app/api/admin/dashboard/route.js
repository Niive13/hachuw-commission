var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__088p40a._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_dashboard_route_actions_1ispso-.js")
R.m(29681)
module.exports=R.m(29681).exports
