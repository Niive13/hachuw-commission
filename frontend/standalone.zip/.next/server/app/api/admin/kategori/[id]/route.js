var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/kategori/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1099myk._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_kategori_[id]_route_actions_1jw16cu.js")
R.m(82805)
module.exports=R.m(82805).exports
