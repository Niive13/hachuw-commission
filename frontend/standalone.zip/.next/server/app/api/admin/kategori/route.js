var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/kategori/route.js")
R.c("server/chunks/[root-of-the-server]__1_iebbp._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_kategori_route_actions_1-pwa37.js")
R.m(83078)
module.exports=R.m(83078).exports
