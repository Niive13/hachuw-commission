var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/portofolio/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__03on2aa._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_portofolio_[id]_route_actions_0s1d8ka.js")
R.m(48797)
module.exports=R.m(48797).exports
