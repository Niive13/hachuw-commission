var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/queue/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0zov7fe._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_queue_[id]_route_actions_06aiyix.js")
R.m(75493)
module.exports=R.m(75493).exports
