var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/queue/reorder/route.js")
R.c("server/chunks/[root-of-the-server]__028cr5a._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_queue_reorder_route_actions_1ow4yve.js")
R.m(56909)
module.exports=R.m(56909).exports
