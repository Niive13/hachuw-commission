var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/queue/route.js")
R.c("server/chunks/[root-of-the-server]__0g4-que._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0dgt-0s._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_queue_route_actions_0k7bt8s.js")
R.m(3306)
module.exports=R.m(3306).exports
