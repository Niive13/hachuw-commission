module.exports=[78235,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_artworks_%5Bid%5D_image_route_actions_05go0gd.js.map