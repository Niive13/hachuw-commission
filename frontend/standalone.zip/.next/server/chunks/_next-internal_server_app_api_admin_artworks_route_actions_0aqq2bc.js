module.exports=[5085,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_artworks_route_actions_0aqq2bc.js.map