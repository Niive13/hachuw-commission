module.exports=[22042,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_catalog_%5Bid%5D_images_route_actions_1bumu5x.js.map