module.exports=[78069,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_kategori_%5Bid%5D_route_actions_1jw16cu.js.map