module.exports=[84261,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_kategori_route_actions_1-pwa37.js.map