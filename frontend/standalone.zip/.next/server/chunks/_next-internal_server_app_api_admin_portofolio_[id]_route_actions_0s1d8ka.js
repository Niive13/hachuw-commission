module.exports=[93522,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_portofolio_%5Bid%5D_route_actions_0s1d8ka.js.map