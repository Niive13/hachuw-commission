module.exports=[71139,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_artwork_page_actions_1k4ih_g.js.map