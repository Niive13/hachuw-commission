module.exports=[96044,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_catalog_%5Bid%5D_page_actions_02tjfrp.js.map