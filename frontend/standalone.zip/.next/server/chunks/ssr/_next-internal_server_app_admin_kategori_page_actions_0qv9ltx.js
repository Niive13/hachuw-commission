module.exports=[2659,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_kategori_page_actions_0qv9ltx.js.map