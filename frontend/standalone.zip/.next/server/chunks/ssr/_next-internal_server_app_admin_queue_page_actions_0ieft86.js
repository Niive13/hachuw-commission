module.exports=[7192,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_queue_page_actions_0ieft86.js.map