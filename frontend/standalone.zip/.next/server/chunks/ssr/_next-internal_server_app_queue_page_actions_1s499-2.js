module.exports=[74406,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_queue_page_actions_1s499-2.js.map