module.exports=[55890,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_rules_page_actions_1klva6x.js.map