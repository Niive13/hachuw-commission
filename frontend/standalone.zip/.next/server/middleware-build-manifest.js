globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/1izNwbKhH6z2S3t3jKEW3/_buildManifest.js",
    "static/1izNwbKhH6z2S3t3jKEW3/_ssgManifest.js",
    "static/1izNwbKhH6z2S3t3jKEW3/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1o6czahs1vdgb.js",
    "static/chunks/0_c1a1tavjtwo.js",
    "static/chunks/1nlckiz-m87_x.js",
    "static/chunks/1b597fu2ax32s.js",
    "static/chunks/turbopack-1m4pdp94_1rye.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
